package TaskContract;

public class TaskEntry {
    public static final String COL_TASK_TITLE = ;
    public static final String TABLE = ;
    public static final String _ID = ;
}
