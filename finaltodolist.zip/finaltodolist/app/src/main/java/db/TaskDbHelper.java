package com.cs260class.todolist.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Objects;

import TaskContract.TaskEntry;

public class TaskDbHelper extends SQLiteOpenHelper {

    private Object TaskContract;

    public TaskDbHelper(Context context) {
        super(context, Objects.requireNonNull(TaskContract).DB_NAME, null, TaskContract.DB_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable;
        createTable = "CREATE TABLE " + TaskEntry.TABLE + " ( " +
                TaskEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TaskEntry.COL_TASK_TITLE + " TEXT NOT NULL);";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TaskEntry.TABLE);
        onCreate(db);
    }
}